package com.azani.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.IBinder

class AzanPlaybackService : Service() {
    private var player: MediaPlayer? = null
    private val channelId = "azani_playback"
    override fun onCreate() { super.onCreate(); createChannel() }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.getStringExtra("action") == "STOP") {
            player?.stopSafely(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY
        }
        startForeground(44, notification())
        player?.stopSafely()
        val key = intent?.getStringExtra("sound_key") ?: "all"
        val prefs = getSharedPreferences("azani", MODE_PRIVATE)
        val raw = prefs.getString("sound_$key", null) ?: prefs.getString("sound_all", null)
        if (raw != null) {
            try {
                player = MediaPlayer().apply {
                    setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                    setDataSource(this@AzanPlaybackService, Uri.parse(raw))
                    setOnCompletionListener { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
                    setOnErrorListener { _, _, _ -> stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); true }
                    prepare(); start()
                }
            } catch (_: Exception) { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
        } else {
            stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
        }
        return START_NOT_STICKY
    }
    private fun MediaPlayer.stopSafely() { try { if (isPlaying) stop(); release() } catch (_: Exception) {} }
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "تنبيهات أذاني", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }
    private fun notification(): Notification {
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId)
            .setContentTitle("أذاني").setContentText("تشغيل صوت التنبيه").setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentIntent(open).setOngoing(true).build()
        else @Suppress("DEPRECATION") Notification.Builder(this).setContentTitle("أذاني").setContentText("تشغيل صوت التنبيه").setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentIntent(open).build()
    }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { player?.stopSafely(); player = null; super.onDestroy() }
}
