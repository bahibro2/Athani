package com.azani.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            // MainActivity recalculates and schedules the next prayer when opened.
            // Open the app once after installation and after changing permissions.
        }
    }
}
