package com.azani.app

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity(), SensorEventListener {
    private val gold = Color.rgb(224, 181, 76)
    private val black = Color.rgb(18, 18, 20)
    private lateinit var root: LinearLayout
    private lateinit var countdown: TextView
    private lateinit var qibla: TextView
    private val prefs by lazy { getSharedPreferences("azani", MODE_PRIVATE) }
    private val prayers = listOf("الفجر", "الظهر", "العصر", "المغرب", "العشاء")
    private var sensorManager: SensorManager? = null
    private var rotation = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = black
        window.navigationBarColor = black
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 12)
        buildUi()
        scheduleNextPrayer()
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(22, 28, 22, 24); setBackgroundColor(black)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        val title = TextView(this).apply { text = "☾ أذاني"; textSize = 32f; setTextColor(gold); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER }
        content.addView(title, lp(-1, -2))
        content.addView(TextView(this).apply {
            text = "الوادي، الجزائر  •  مواقيت محلية دون إنترنت"; textSize = 14f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
        }, lp(-1, -2))
        countdown = TextView(this).apply { textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, 22, 0, 12) }
        content.addView(countdown, lp(-1, -2))
        content.addView(TextView(this).apply {
            text = "الأوقات تقديرية؛ راجع طريقة الحساب المعتمدة محليًا."; textSize = 12f; setTextColor(gold); gravity = Gravity.CENTER
        }, lp(-1, -2))
        val times = prayerTimes(Calendar.getInstance())
        val timeText = prayers.indices.joinToString("\n") { i -> "${prayers[i]}     ${String.format(Locale.getDefault(), "%02d:%02d", times[i] / 60, times[i] % 60)}" }
        content.addView(TextView(this).apply { text = timeText; textSize = 18f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, 18, 0, 18) }, lp(-1, -2))
        content.addView(button("اختيار صوت موحّد") { chooseSound("all") })
        prayers.forEachIndexed { i, prayer -> content.addView(button("اختيار صوت $prayer") { chooseSound(prayer) }) }
        content.addView(button("تشغيل أذان تجريبي") { startPlayback("all", false) })
        content.addView(button("ضبط منبّه يدوي بعد دقيقة") { scheduleManual() })
        content.addView(button("تأجيل التنبيه 5 دقائق") {
            val intent = Intent(this, AzanPlaybackService::class.java).putExtra("action", "STOP")
            startService(intent)
            scheduleSnooze()
            Toast.makeText(this, "تم طلب التأجيل 5 دقائق", Toast.LENGTH_SHORT).show()
        })
        qibla = TextView(this).apply { text = "اتجاه القبلة: جارٍ تحديد اتجاه البوصلة…"; textSize = 17f; setTextColor(gold); gravity = Gravity.CENTER; setPadding(0, 20, 0, 8) }
        content.addView(qibla, lp(-1, -2))
        content.addView(TextView(this).apply { text = "تنبيه: اسمح للتطبيق بالإشعارات والمنبّهات الدقيقة، واستثنه من تحسين البطارية لضمان التنبيه بالخلفية."; textSize = 12f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; setPadding(0, 12, 0, 0) }, lp(-1, -2))
        scroll.addView(content); root.addView(scroll, lp(-1, -1)); setContentView(root)
        updateCountdown()
    }

    private fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h).apply { bottomMargin = 10 }
    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label; setTextColor(Color.BLACK); setBackgroundColor(gold); textSize = 14f
        setOnClickListener { action() }
    }

    private fun chooseSound(key: String) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "audio/*" }
        startActivityForResult(i, if (key == "all") 100 else 101 + prayers.indexOf(key))
        prefs.edit().putString("pending_key", key).apply()
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        val key = prefs.getString("pending_key", "all") ?: "all"
        prefs.edit().putString("sound_$key", uri.toString()).apply()
        Toast.makeText(this, "تم حفظ الصوت: ${fileName(uri)}", Toast.LENGTH_LONG).show()
    }

    private fun fileName(uri: Uri): String {
        var result = "ملف صوتي"
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) { val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (idx >= 0) result = c.getString(idx) }
        }
        return result
    }

    private fun scheduleManual() {
        val c = Calendar.getInstance().apply { add(Calendar.MINUTE, 1) }
        scheduleAlarm(c.timeInMillis, "manual", 777)
        Toast.makeText(this, "تم ضبط منبّه بعد دقيقة", Toast.LENGTH_SHORT).show()
    }

    private fun scheduleSnooze() {
        scheduleAlarm(System.currentTimeMillis() + 5 * 60_000L, "all", 778)
    }

    private fun scheduleAlarm(time: Long, key: String, id: Int) {
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, PrayerAlarmReceiver::class.java).putExtra("sound_key", key)
        val pi = PendingIntent.getBroadcast(this, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        try {
            if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, pi)
            else am.setExact(AlarmManager.RTC_WAKEUP, time, pi)
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, pi)
            Toast.makeText(this, "فعّل صلاحية المنبّهات الدقيقة من إعدادات أذاني", Toast.LENGTH_LONG).show()
        }
    }

    private fun scheduleNextPrayer() {
        val now = Calendar.getInstance()
        val times = prayerTimes(now)
        val minuteNow = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
        var idx = times.indexOfFirst { it > minuteNow }
        val target = Calendar.getInstance()
        if (idx < 0) { target.add(Calendar.DAY_OF_YEAR, 1); idx = 0 }
        target.set(Calendar.HOUR_OF_DAY, times[idx] / 60); target.set(Calendar.MINUTE, times[idx] % 60); target.set(Calendar.SECOND, 0); target.set(Calendar.MILLISECOND, 0)
        if (target.timeInMillis <= System.currentTimeMillis()) target.add(Calendar.DAY_OF_YEAR, 1)
        scheduleAlarm(target.timeInMillis, prayers[idx], 300 + idx)
    }

    // Lightweight offline approximation for El Oued (33.37 N, 6.85 E), angles approximated.
    private fun prayerTimes(cal: Calendar): List<Int> {
        val day = cal.get(Calendar.DAY_OF_YEAR).toDouble()
        val decl = Math.toRadians(23.45 * kotlin.math.sin(Math.toRadians(360.0 * (284.0 + day) / 365.0)))
        val lat = Math.toRadians(33.37)
        val noon = 12.0 - 6.85 / 15.0
        fun hourAngle(altDeg: Double): Double {
            val alt = Math.toRadians(altDeg)
            val cosH = (kotlin.math.sin(alt) - kotlin.math.sin(lat) * kotlin.math.sin(decl)) / (kotlin.math.cos(lat) * kotlin.math.cos(decl))
            return Math.toDegrees(kotlin.math.acos(cosH.coerceIn(-1.0, 1.0))) / 15.0
        }
        val fajr = noon - hourAngle(-18.0)
        val sunrise = noon - hourAngle(-0.833)
        val dhuhr = noon + 0.05
        val asrAngle = kotlin.math.atan(1.0 / (1.0 + kotlin.math.tan(kotlin.math.abs(lat - decl))))
        val asr = noon + Math.toDegrees(kotlin.math.acos(((kotlin.math.sin(asrAngle) - kotlin.math.sin(lat) * kotlin.math.sin(decl)) / (kotlin.math.cos(lat) * kotlin.math.cos(decl))).coerceIn(-1.0, 1.0))) / 15.0
        val maghrib = noon + hourAngle(-0.833)
        val isha = noon + hourAngle(-17.0)
        fun minOfDay(h: Double) = ((h * 60).toInt()).coerceIn(0, 1439)
        return listOf(minOfDay(fajr), minOfDay(dhuhr), minOfDay(asr), minOfDay(maghrib), minOfDay(isha))
    }

    private fun updateCountdown() {
        val now = Calendar.getInstance()
        val times = prayerTimes(now)
        val mins = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
        val idx = times.indexOfFirst { it > mins }
        val next = if (idx >= 0) times[idx] else times[0] + 1440
        val remain = next - mins
        val name = if (idx >= 0) prayers[idx] else prayers[0]
        countdown.text = "الصلاة القادمة: $name\nمتبقٍ ${remain / 60} ساعة و${remain % 60} دقيقة"
    }

    private fun startPlayback(key: String, fromAlarm: Boolean) {
        val service = Intent(this, AzanPlaybackService::class.java).putExtra("sound_key", key)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
    }

    override fun onResume() {
        super.onResume()
        sensorManager?.getDefaultSensor(Sensor.TYPE_ORIENTATION)?.also { sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
        updateCountdown()
    }
    override fun onPause() { super.onPause(); sensorManager?.unregisterListener(this) }
    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type == Sensor.TYPE_ORIENTATION) {
            rotation = event.values[0]
            // Approximate bearing from El Oued to Kaaba.
            val lat1 = Math.toRadians(33.37); val lon1 = Math.toRadians(6.85)
            val lat2 = Math.toRadians(21.4225); val lon2 = Math.toRadians(39.8262)
            val bearing = (Math.toDegrees(kotlin.math.atan2(kotlin.math.sin(lon2-lon1)*kotlin.math.cos(lat2),
                kotlin.math.cos(lat1)*kotlin.math.sin(lat2)-kotlin.math.sin(lat1)*kotlin.math.cos(lat2)*kotlin.math.cos(lon2-lon1))) + 360) % 360
            val relative = (bearing - rotation + 360) % 360
            qibla.text = "اتجاه القبلة: ${bearing.toInt()}° من الشمال\nحرّك الهاتف؛ الاتجاه النسبي ${relative.toInt()}°"
        }
    }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
